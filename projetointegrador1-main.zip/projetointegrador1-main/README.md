# Projeto integrador

Esse é um projeto para a matéria de Projeto Integrador dos alunos do Eixo Computação da UNIVESP.

## Features
- Login
- Autenticação de login
- Armazenamento criptografado de senhas
- Cadastro de animais para doação
- Fotos e descrição dos animais
- Informações pertinentes a adoção
